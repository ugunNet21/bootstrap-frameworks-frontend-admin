Thanks for downloading this template!

Template Name: Anyar
Template URL: https://bootstrapmade.com/anyar-free-multipurpose-one-page-bootstrap-theme/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
